# technicaltest > Technicaltest
https://universe.roboflow.com/skripsi-umyk5/technicaltest

Provided by a Roboflow user
License: CC BY 4.0

